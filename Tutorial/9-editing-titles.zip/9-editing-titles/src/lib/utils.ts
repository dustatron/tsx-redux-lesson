export const addZero = (num: number) => (num < 10 ? `0${num}` : `${num}`);
