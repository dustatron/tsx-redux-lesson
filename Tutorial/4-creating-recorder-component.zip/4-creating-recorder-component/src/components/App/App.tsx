import React from 'react';
import './App.css';
import Recorder from '../Recorder';

const App: React.FC = () => {
  return (
    <div className="App">
      <Recorder />
    </div>
  );
};

export default App;
